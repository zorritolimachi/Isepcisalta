# ISEPCI Salta · sitio institucional (v8)

Sitio estático (HTML + CSS + JavaScript propio). **No requiere compilación ni dependencias**, por lo que no hay `node_modules` ni versión de Node que fijar.

## Cloudflare Pages
- Framework preset: **None**
- Build command: *(vacío)*
- Build output directory: **/** (la raíz de este proyecto; donde está `index.html`)
- Variables de entorno: ninguna

Pasos: Workers & Pages → Create → Pages → *Upload assets* (o conectar el repositorio) → nombrar el proyecto → subir la carpeta descomprimida (o el ZIP) → Deploy.
`_headers` y `_redirects` son compatibles con Cloudflare Pages. Para vista previa local: `python3 -m http.server` en esta carpeta (el sitio carga `/data/*.json`, por eso no funciona abriendo `index.html` con doble clic).

## Cómo actualizar
- Informes: `data/informes.json` (+ PDF en `/informes/`, páginas del visor en `/documentos/<id>/`, portada en `/assets/covers/`).
- Noticias: `data/noticias.json` (solo Salta; `fecha` puede ser null).
- Opinión: `data/opinion.json`.
- Fotos: originales sin tocar en `assets/fotos/originales/`; versiones web `.webp` + `.jpg` de respaldo en `assets/fotos/`.

## Pendientes conocidos
- Los informes anteriores solo existen como páginas-imagen (visor de lectura); los PDF originales no venían en el ZIP v7.
- Las páginas internas de Opinión y los visores de documentos conservan el diseño anterior.
