(() => {
  const toggle = document.querySelector('.menu-toggle');
  const nav = document.getElementById('main-nav');
  if (toggle && nav) {
    toggle.addEventListener('click', () => {
      const open = toggle.getAttribute('aria-expanded') === 'true';
      toggle.setAttribute('aria-expanded', String(!open));
      nav.classList.toggle('is-open', !open);
    });
    nav.addEventListener('click', (event) => {
      if (event.target.closest('a')) {
        toggle.setAttribute('aria-expanded', 'false');
        nav.classList.remove('is-open');
      }
    });
  }

  const title = document.querySelector('h1')?.textContent?.trim() || document.title;
  const url = document.querySelector('link[rel="canonical"]')?.href || window.location.href;
  const status = document.querySelector('[data-share-status]');
  const say = (message) => {
    if (status) status.textContent = message;
  };
  const copyLink = async (message = 'Enlace copiado al portapapeles.') => {
    try {
      await navigator.clipboard.writeText(url);
      say(message);
    } catch {
      const field = document.createElement('textarea');
      field.value = url;
      field.setAttribute('readonly', '');
      field.style.position = 'fixed';
      field.style.opacity = '0';
      document.body.appendChild(field);
      field.select();
      const copied = document.execCommand('copy');
      field.remove();
      say(copied ? message : `Copia este enlace: ${url}`);
    }
  };

  const whatsapp = document.querySelector('[data-share-whatsapp]');
  if (whatsapp) {
    const wa = new URL('https://wa.me/');
    wa.searchParams.set('text', `${title} — ${url}`);
    whatsapp.href = wa.toString();
  }
  const facebook = document.querySelector('[data-share-facebook]');
  if (facebook) {
    const fb = new URL('https://www.facebook.com/sharer/sharer.php');
    fb.searchParams.set('u', url);
    facebook.href = fb.toString();
  }

  document.querySelector('[data-share-native]')?.addEventListener('click', async () => {
    if (navigator.share) {
      try {
        await navigator.share({ title, text: `Nota de ${document.querySelector('meta[name="author"]')?.content || 'ISEPCI Salta'}, publicada por Libres del Sur.`, url });
      } catch (error) {
        if (error?.name !== 'AbortError') say('No se pudo abrir el menú de compartir. Usa los enlaces o copia la URL.');
      }
    } else {
      await copyLink();
    }
  });

  document.querySelectorAll('[data-copy-link]').forEach((button) => {
    button.addEventListener('click', () => copyLink(button.dataset.copyMessage || 'Enlace copiado al portapapeles.'));
  });
})();
