(()=>{
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const norm=s=>String(s??'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
const MES=['enero','febrero','marzo','abril','mayo','junio','julio','agosto','septiembre','octubre','noviembre','diciembre'];
const fdate=d=>{if(!d)return 'Fecha no indicada';const[y,m,dd]=d.split('-');return `${+dd} de ${MES[+m-1]} de ${y}`};
const reduce=matchMedia('(prefers-reduced-motion: reduce)').matches;
/* menú */
const bg=$('.burger'),mn=$('#mnav');bg.onclick=()=>{const o=bg.getAttribute('aria-expanded')==='true';bg.setAttribute('aria-expanded',!o);mn.classList.toggle('open',!o)};mn.onclick=e=>{if(e.target.closest('a')){bg.setAttribute('aria-expanded','false');mn.classList.remove('open')}};
/* carrusel */
const sl=$$('.slide'),dots=$('#dots');let cur=0,timer=null,playing=!reduce;
sl.forEach((_,i)=>{const b=document.createElement('button');b.setAttribute('aria-label',`Ir a la diapositiva ${i+1}`);b.onclick=()=>{go(i);}; dots.append(b)});
function go(i){cur=(i+sl.length)%sl.length;sl.forEach((s,k)=>{s.classList.toggle('on',k===cur);s.setAttribute('aria-hidden',k!==cur)});$$('button',dots).forEach((b,k)=>b.setAttribute('aria-current',k===cur));if(playing)restart()}
function restart(){clearInterval(timer);timer=setInterval(()=>go(cur+1),7500)}
function setPlay(p){playing=p;$('#pp').textContent=p?'❚❚':'▶';$('#pp').setAttribute('aria-label',p?'Pausar rotación automática':'Reanudar rotación automática');p?restart():clearInterval(timer)}
$('#prev').onclick=()=>go(cur-1);$('#next').onclick=()=>go(cur+1);$('#pp').onclick=()=>setPlay(!playing);
const hero=$('.hero');hero.addEventListener('mouseenter',()=>{if(playing)clearInterval(timer)});hero.addEventListener('mouseleave',()=>{if(playing)restart()});hero.addEventListener('focusin',()=>{if(playing)clearInterval(timer)});
hero.addEventListener('keydown',e=>{if(e.key==='ArrowLeft')go(cur-1);if(e.key==='ArrowRight')go(cur+1)});
let sx=0;hero.addEventListener('touchstart',e=>sx=e.touches[0].clientX,{passive:true});hero.addEventListener('touchend',e=>{const d=e.changedTouches[0].clientX-sx;if(Math.abs(d)>50)go(cur+(d<0?1:-1))});
go(0);if(playing)restart();
/* gráficos (datos del informe N.º 07) */
(function(){const L=['2S 2023','1S 2024','2S 2024','1S 2025','2S 2025','1S 2026'],N=[41.7,52.9,38.1,31.6,28.2,32.3],S=[42.4,52.2,41.2,29.5,29.7,29.7];
const W=520,H=300,p={l:36,r:16,t:20,b:36},x=i=>p.l+i*(W-p.l-p.r)/5,y=v=>H-p.b-v/60*(H-p.t-p.b);
const fm=v=>String(v).replace('.',',')+'%';let g='';[0,20,40,60].forEach(v=>g+=`<line x1="${p.l}" x2="${W-p.r}" y1="${y(v)}" y2="${y(v)}" stroke="currentColor" opacity=".12"/><text x="4" y="${y(v)+4}">${v}</text>`);
L.forEach((l,i)=>g+=`<text x="${x(i)}" y="${H-12}" text-anchor="middle">${l}</text>`);
const line=(a,c,dash,off)=>`<polyline fill="none" stroke="${c}" stroke-width="3" ${dash?'stroke-dasharray="7 5"':''} points="${a.map((v,i)=>x(i)+','+y(v)).join(' ')}"/>`+a.map((v,i)=>`<circle cx="${x(i)}" cy="${y(v)}" r="4.5" fill="${c}"/><text class="${dash?'':'v'}" x="${x(i)}" y="${y(v)+off}" text-anchor="middle">${fm(v)}</text>`).join('');
g+=line(N,'#8a97ad',true,-10)+line(S,'#0f2f5c',false,19);
$('#ch-pobreza').innerHTML=`<svg class="ch" viewBox="0 0 ${W} ${H}" role="img" aria-label="Pobreza, total 31 aglomerados: ${N.map(fm).join(', ')}. Aglomerado Salta: ${S.map(fm).join(', ')}.">${g}</svg>`;
const B=[['Hogares con algún tipo de deuda',86],['Hogares en mora',77],['Re-endeudados para afrontar una deuda anterior',72]];
$('#bars').innerHTML=B.map(([t,v])=>`<div class="bar"><b><span>${t}</span><span>${v}%</span></b><div><i style="width:${v}%"></i></div></div>`).join('')})();
/* biblioteca */
let REP=[],tag='',cur2='';const lib=$('#lib');
const repCard=r=>`<article class="rep"><a class="im" href="${r.visor}" tabindex="-1" aria-hidden="true"><img src="${r.portada}" alt="" loading="lazy"></a><div class="b"><div>${r.tags.slice(0,3).map(t=>`<span class="tag">${esc(t)}</span>`).join('')}</div><h3>${esc(r.titulo)}</h3><p class="meta">${esc(r.fecha_txt)} · ${esc(r.alcance)}</p><p style="margin:0;font-size:.92rem">${esc(r.descripcion)}</p>${r.resultados.length?`<ul>${r.resultados.slice(0,3).map(x=>`<li>${esc(x)}</li>`).join('')}</ul>`:''}<details><summary>Metodología</summary><p style="margin:6px 0 0">${esc(r.metodologia)}</p></details><div class="acts"><a class="btn sm" href="${r.visor}">Leer informe</a>${r.pdf?`<a class="btn sm ghost" href="${r.pdf}" target="_blank" rel="noopener">PDF original</a>`:''}<button class="btn sm ghost" data-share="${r.id}">Compartir</button></div></div></article>`;
function draw(){const q=norm($('#q').value),y=$('#yr').value;const L=REP.filter(r=>(!tag||r.tags.includes(tag))&&(!y||r.fecha.startsWith(y))&&(!q||norm([r.titulo,r.descripcion,r.tema,r.tags.join(' '),r.resultados.join(' '),r.metodologia].join(' ')).includes(q)));
$('#count').textContent=`${L.length} ${L.length===1?'investigación':'investigaciones'}`;lib.innerHTML=L.length?L.map(repCard).join(''):'<p class="empty">No hay investigaciones con ese criterio.</p>'}
fetch('/data/informes.json').then(r=>r.json()).then(d=>{REP=d.items.sort((a,b)=>b.fecha.localeCompare(a.fecha));
const T=['Todas',...[...new Set(REP.flatMap(r=>r.tags))].sort()];$('#chips').innerHTML=T.map((t,i)=>`<button class="chip" aria-pressed="${i===0}" data-t="${i?esc(t):''}">${esc(t)}</button>`).join('');
$('#chips').onclick=e=>{const b=e.target.closest('.chip');if(!b)return;tag=b.dataset.t;$$('.chip',$('#chips')).forEach(c=>c.setAttribute('aria-pressed',c===b));draw()};
[...new Set(REP.map(r=>r.fecha.slice(0,4)))].sort().reverse().forEach(y=>$('#yr').insertAdjacentHTML('beforeend',`<option>${y}</option>`));
$('#q').oninput=draw;$('#yr').onchange=draw;draw()}).catch(()=>lib.innerHTML='<p class="empty">No se pudo cargar la biblioteca.</p>');
document.addEventListener('click',e=>{const b=e.target.closest('[data-share]');if(!b)return;const r=REP.find(x=>x.id===b.dataset.share)||{titulo:'Pobreza, empleo y protección social',visor:'/documento/pobreza-empleo-proteccion-social/'};const u=location.origin+r.visor;
if(navigator.share)navigator.share({title:r.titulo,text:'ISEPCI Salta · '+r.titulo,url:u}).catch(()=>{});else{(navigator.clipboard?navigator.clipboard.writeText(u):Promise.reject()).then(()=>{b.textContent='Enlace copiado'},()=>prompt('Copiá el enlace:',u))}});
/* noticias */
fetch('/data/noticias.json').then(r=>r.json()).then(d=>{const I=d.items.sort((a,b)=>(b.fecha||'').localeCompare(a.fecha||''));const F=['Todas','Federico Maigua','Darío Limachi','ISEPCI Salta','Libres del Sur Salta'];let f='';
const dr=()=>{const L=I.filter(n=>!f||n.tags.includes(f)||n.personas.includes(f));$('#news').innerHTML=L.length?L.map(n=>`<article class="nw"><div class="im">${n.imagen?`<img src="${n.imagen}" alt="" loading="lazy">`:esc(n.medio)}</div><div class="b"><p class="meta">${esc(n.medio)} · ${fdate(n.fecha)}</p><h3>${esc(n.titulo)}</h3><p>${esc(n.resumen)}</p>${n.personas.length?`<p class="meta">Mencionado/a: ${esc(n.personas.join(', '))}</p>`:''}<div class="acts"><a class="btn sm ghost" href="${esc(n.enlace)}" target="_blank" rel="noopener noreferrer">Leer en ${esc(n.medio)}</a></div></div></article>`).join(''):'<p class="empty">Todavía no hay publicaciones verificadas en esta categoría.</p>'};
$('#nchips').innerHTML=F.map((t,i)=>`<button class="chip" aria-pressed="${i===0}" data-t="${i?t:''}">${t}</button>`).join('');$('#nchips').onclick=e=>{const b=e.target.closest('.chip');if(!b)return;f=b.dataset.t;$$('.chip',$('#nchips')).forEach(c=>c.setAttribute('aria-pressed',c===b));dr()};dr()});
/* opinión */
fetch('/data/opinion.json').then(r=>r.json()).then(d=>{$('#op').innerHTML=d.items.map(o=>`<article class="opc"><img src="${o.foto}" alt="${esc(o.autor)}" loading="lazy"><div><p class="meta">${esc(o.autor)} · ${esc(o.cargo)}<br>${o.fecha?fdate(o.fecha):'Fecha no indicada en el documento original'}</p><h3>${esc(o.titulo)}</h3><p style="margin:0 0 12px;font-size:.92rem">${esc(o.intro)}</p><div class="acts"><a class="btn sm" href="${o.enlace}">Leer la nota</a><a class="btn sm ghost" href="${o.original}">Documento original</a></div></div></article>`).join('')});
/* reveal */
if('IntersectionObserver'in window&&!reduce){const io=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){e.target.classList.add('in');io.unobserve(e.target)}}),{threshold:.08});$$('.reveal').forEach(el=>io.observe(el))}else $$('.reveal').forEach(el=>el.classList.add('in'));
})();
