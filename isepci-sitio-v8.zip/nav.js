/* Menú «Áreas de trabajo»: se cierra al hacer clic afuera, con Escape o al elegir una opción. */
(function(){
  const d=document.querySelector('.nav-drop'); if(!d) return;
  document.addEventListener('click',e=>{ if(d.open && !d.contains(e.target)) d.open=false; });
  document.addEventListener('keydown',e=>{ if(e.key==='Escape' && d.open){ d.open=false; d.querySelector('summary').focus(); } });
  d.querySelectorAll('.nav-sub a').forEach(a=>a.addEventListener('click',()=>{ d.open=false; }));
})();
